<?php
$__smtp = array(
    "host" => "smtp.ukr.net", //smtp сервер
    "debug" => 2,                   //отображение информации дебаггера (0 - нет вообще)
    "auth" => true,                 //сервер требует авторизации
    "port" => 2525,                    //порт (по-умолчанию - 25)
    "username" => "naaa",//имя пользователя на сервере
    "password" => "98465703nazik",//пароль
    "addreply" => "naaa@ukr.net",//ваш е-mail
    "replyto" => "naaa@ukr.net"      //e-mail ответа
);
?>