<script language="javascript">
query='width=' + screen.width + '&height=' + screen.height;

document.write("<a href=script.php?" + query + ">ссылка</a>");
</script>