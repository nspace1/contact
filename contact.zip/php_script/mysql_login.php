<?php
 $db_hostname = 'localhost';
 $db_database = 'contact_mananger';
 $db_username = 'naaa';
 $db_password = '98465703';

 
 ?>