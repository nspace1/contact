<php?
echo "Contact your administrator";
?>